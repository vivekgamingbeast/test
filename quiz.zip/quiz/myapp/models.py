from django.db import models

# Create your models here.
class Quiz(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=1000)


class Question(models.Model):
    name = models.CharField(max_length=100)
    options = models.CharField(max_length=200)
    correct_option = models.CharField(max_length=100)
    quiz = models.ForeignKey(Quiz, on_delete=models.DO_NOTHING)
    points = models.IntegerField(20)
