from django.shortcuts import render
from .models import Quiz, Question
from .serializers import QuizSerializer, QuestionSerializer
from rest_framework import viewsets


class QuizViewSet(viewsets.ModelViewSet):
    queryset = Quiz.objects.all()
    serializer_class = QuizSerializer

class QuestionViewSet(viewsets.ModelViewSet):
    queryset = Question.objects.all()
    serializer_class = QuestionSerializer